package com.fakestore.ecom;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiService {
    String BASE_URL = "http://fakestoreapi.com/";

    @GET("products")
    Call<String> getProducts();
}