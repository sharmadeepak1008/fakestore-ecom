package com.fakestore.ecom;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ProductDetail extends AppCompatActivity {
    @BindView(R.id.product_name)
    TextView title;
    @BindView(R.id.product_category)
    TextView category;
    @BindView(R.id.product_rating)
    TextView rating;
    @BindView(R.id.product_description)
    TextView description;
    @BindView(R.id.product_price)
    TextView price;
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.expandedImage)
    ImageView imageView;


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);
        ButterKnife.bind(this);
        //toolbar.setSubtitle("Fake Store Ecom Product");
        title.setText(getIntent().getStringExtra("title"));
        category.setText(getIntent().getStringExtra("category"));
        description.setText(getIntent().getStringExtra("description"));
        price.setText(getIntent().getStringExtra("price"));
       // rating.setText(getIntent().getStringExtra("rating"));
        Picasso.get().load(getIntent().getStringExtra("image")).into(imageView);



    }
}