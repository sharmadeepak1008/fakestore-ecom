package com.fakestore.ecom;

import android.view.View;

public interface OnItemClickListener {
    void onItemClick(View view, int position);
}
